package com.uvgmeetf.uvgmeetf;

public class Session {
    private int id;
    private String user;
    Session(){

    }

    public int getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
